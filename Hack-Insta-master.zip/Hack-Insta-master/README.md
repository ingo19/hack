# instahack


###### [*] Hack instagram accounts use bruteforce
###### [*] for more proxy - go to https://www.torvpn.com/en/proxy-list




<h1 align="center">INSTA H4CK3R </h1>
<p align="center">
      New Tool for Instagram Hacking. Bruteforce Method
</p>

## About INSTA H4CK3R :

Insta Hacker is a python based Script. You can use this script for hacking Instagram (bruteforce). 

![](https://github.com/Stephin-Franklin/Hack-Insta/blob/master/Screenshot_20191207-024415.png)

### INSTA H4CK3R is available for

• Termux

• Kali-Linux

• Ubuntu 

### Installation and usage guide
```
```
$ apt-get update -y
```
```
$ apt-get upgrade -y
```
```
$ pkg install git -y
```
```
$ git clone https://github.com/Stephin-Franklin/Hack-Insta
```
```
$ ls
```
```
$ cd Hack-Insta
```
```
$ ls
```
```
$ pkg install nano
```
```
$ Now Enter Some password 
```
```
$ CTRL + X
```
```
$ python2 hackinsta.py

* Now it will Ask for Username. Enter Your Target Username
```
```
* Then it will ask you for, Do you want to use proxy or not (Optional)
```
```
• After All. It will Start Finding Password 
```

### Subscribe our channel on youtube
https://www.youtube.com/AnonymousTim3


### Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
